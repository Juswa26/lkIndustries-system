<?php 
    
    if(!isset($_SESSION['admin_email'])){
        echo "<script>window.open('login.php','_self')</script>";
    }else{

?>

<div class="row mt-5"><!-- row 1 Start -->
    <div class="col-lg-12"><!-- col-lg-12 Start -->
        <ol class="breadcrumb"><!-- breadcrumb Start -->
            <li>  
                <i class="fa fa-dashboard"></i> Dashboard / View Admin Users   
            </li>
        </ol><!-- breadcrumb finish -->
    </div><!-- col-lg-12 finish -->
</div><!-- row 1 finish -->

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">
                    <i class="fa fa-tags fa-fw"></i> Admin list
                </h3>
            </div>

            <div class="panel-body"><!-- panel-body begin -->
                <div class="table-responsive"><!-- table-responsive begin -->
                    <table id="admin_table" class="table table-hover table-striped table-bordered">
                        <thead><!-- thead begin -->

                            <tr><!-- tr begin -->
                            <th> #</th>
                            <th> Admin_Code</th>
                                <th> Admin_Profile_Picture</th>
                                <th> Admin_Name</th>
                                <th> Admin_Role</th>
                                <th> Edit_Admin_User</th>
                                 <th> Delete_Admin_User</th>
                                
                                
                            </tr><!-- tr finish -->
                        </thead><!-- thead finish -->
                        
                        <tbody>
                    
                        <?php
                                $rowNumber = 0;
                                while($admin = mysqli_fetch_assoc($run_admin)) {
                                    $rowNumber++;
                                    $ad_id = $admin['ad_id'];
                                    echo "<tr>";
                                    echo "<td>" . $rowNumber . "</td>"; 
                                    echo "<td>" . $admin['ad_code'] . "</td>";  // Admin ID
                                    echo "<td><img src='img/" . $admin['ad_img'] . "' width='60' height='60'></td>";
                                    echo "<td>" . $admin['ad_name'] . "</td>";  // admin name
                                    echo "<td>" . $admin['ad_role'] . "</td>";  // admin role
                                    echo "<td><a href='index.php?edit_user=" . $ad_id . "' class='btn btn-dark'><i class='fa-solid fa-pen-to-square' style='color: #fff;'></i> Edit Profile</a></td>"; 
                                     

                                        echo "<td>
                                    <a href='index.php?delete_user=" . $ad_id . "' onClick=\"return confirm('Are you sure you want to delete this Account?')\" class='btn btn-danger'>
                                    <i class='fa-solid fa-trash-can' style='color: #fff;'></i> Delete Admin User
                                     </a>
                                 </td>";
                                echo "</tr>";
                                }
                            ?>
                        
                            <!-- <tr>
                                <td>1</td>
                                <td>Change Oil</td>
                                <td>Pinalitan ang Oil</td>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Change Oil</td>
                                <td>Pinalitan ang Oil</td>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr> -->
                            
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php } ?>